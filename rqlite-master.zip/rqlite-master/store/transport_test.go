package store

import (
	"testing"
)

func Test_NewTransport(t *testing.T) {
	if NewTransport(nil) == nil {
		t.Fatal("failed to create new Transport")
	}
}

func Test_NewNodeTransport(t *testing.T) {
	nt := NewNodeTransport(nil, false)
	if nt == nil {
		t.Fatal("failed to create new NodeTransport")
	}
	if err := nt.Close(); err != nil {
		t.Fatalf("failed to close NodeTransport: %s", err.Error())
	}
	if err := nt.Close(); err != nil {
		t.Fatalf("failed to double-close NodeTransport: %s", err.Error())
	}
}
